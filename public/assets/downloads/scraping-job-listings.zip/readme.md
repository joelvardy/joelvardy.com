# Manchester Digital Vacancies Scraper

## Install

```bash
npm install
```

## Run Scrape

*Note: I have left a full scrape `./jobs.json` in the repo so you don't need to wait for one to complete*

```bash
clear && node ./scrape.js
```

## Search Jobs

```bash
php -S 127.0.0.1:1337
```

## TODO

 * Scrape only new jobs and update `./jobs.json`.

Open: http://127.0.0.1:1337/search.html
